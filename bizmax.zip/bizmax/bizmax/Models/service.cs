﻿namespace bizmax.Models
{
    public class service
    { 
        public int Id { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public string content { get; set; }
        public string picture { get; set; }
    }
}
