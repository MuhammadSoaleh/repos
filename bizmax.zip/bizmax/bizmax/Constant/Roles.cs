﻿namespace bizmax.Constant
{
    public enum Roles
    {
        User = 1 ,
        Admin
    }
}
