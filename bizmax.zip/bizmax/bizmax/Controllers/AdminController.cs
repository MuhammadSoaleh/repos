﻿using bizmax.Data;
using bizmax.Models;
using Microsoft.AspNetCore.Mvc;

namespace bizmax.Controllers
{
    public class AdminController : Controller
    {
        
        private readonly ApplicationDbContext appdb;

        public AdminController(ApplicationDbContext appdb) {
            this.appdb = appdb;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(service service, IFormFile img)
        {

            if (img != null && img.Length > 0)
            {
                var ff = Path.GetFileName(img.FileName);
                Random rn = new Random();
                var ii = rn.Next(1, 200);
                var fn = ii + ff;
                var folder = Path.Combine(HttpContext.Request.PathBase.Value, "wwwroot/uploads");
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);

                }
                string fp = Path.Combine(folder, fn);
                using (var a = new FileStream(fp, FileMode.Create))
                {
                    img.CopyTo(a);

                }
                var dba = Path.Combine("image", fp);
                service.picture = dba;
                appdb.services.Add(service);
                appdb.SaveChanges();






            }
            return View();
        }
    }
}
