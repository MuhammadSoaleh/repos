﻿using bizmax.Data;
using bizmax.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace bizmax.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext applicationdb;

        public HomeController(ApplicationDbContext applicationdb)
        {
            this.applicationdb = applicationdb;
        }

        public IActionResult Index()
        {
            return View();
        }
       


        public IActionResult contact()
        {
            return View();
        }
        [HttpPost]
        public IActionResult contact(contact cont)
        {
            var contact1 = new contact
            {
                Name = cont.Name,
                Email = cont.Email,
                Subject = cont.Subject,
                Message = cont.Message
            };
            applicationdb.contacts.Add(contact1);
            applicationdb.SaveChanges();
            return View();
        }
        public IActionResult service()
        {
            return View(applicationdb.services.ToList());
        }
        public IActionResult servicedet(int id)
        {
            return View(applicationdb.services.Find(id));
        }


        public IActionResult about()
        {
            return View();
        }
        public IActionResult bloggrid()
        {
            return View();
        }
        public IActionResult portfolio()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}